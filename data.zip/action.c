Action()
{

	lr_start_transaction("1_transaction_sigin");

	lr_end_transaction("1_transaction_sigin",LR_AUTO);

	lr_start_transaction("1_transaction_selectrepile");

	lr_end_transaction("1_transaction_selectrepile",LR_AUTO);

	lr_start_transaction("1_transaction_myaccont");

	lr_end_transaction("1_transaction_myaccont",LR_AUTO);

	lr_start_transaction("1_transaction_my orders");

	lr_end_transaction("1_transaction_my orders",LR_AUTO);

	lr_start_transaction("1_transaction_signout");

	lr_end_transaction("1_transaction_signout",LR_AUTO);

	return 0;
}